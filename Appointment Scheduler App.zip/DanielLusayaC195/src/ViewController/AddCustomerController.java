package ViewController;

import DBAccess.*;
import Model.*;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/** This class allows a user to add a customer. It controls the AddCustomerScreen FXML user interface. */
public class AddCustomerController implements Initializable {

    Parent scene;
    Stage stage;

    @FXML
    private Label customerIdLbl;

    @FXML
    private TextField addressTxt;

    @FXML
    private TextField zipCodeTxt;

    @FXML
    private TextField phoneNumberTxt;

    @FXML
    private TextField customerNameTxt;

    @FXML
    private ComboBox<Countries> countryCombo;

    @FXML
    private ComboBox<Divisions> divisionCombo;

    /**This method allows the user to add a customer. User input for text fields Name, address, postal code, and
     * phone number and for combo boxes country and division are added to the customer. These values are entered into
     * the database as a new customer using the addCustomerDB method from the DBCustomers class.*/
    @FXML
    void onActionAddCustomer(ActionEvent event) throws IOException {

        String customerName = customerNameTxt.getText();
        String customerAddress = addressTxt.getText();
        String customerPhone = phoneNumberTxt.getText();
        String customerPostalCode = zipCodeTxt.getText();
        Countries countries = countryCombo.getValue();
        Divisions divisions = divisionCombo.getValue();

        DBCustomer.addCustomerDB(customerName, customerAddress, customerPostalCode,
                customerPhone, divisions.getDivisionId());


        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/ViewController/MainScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**This method allows the user to go back to the Main Screen. It warns the user that all text fields will be cleared
     * if the user clicks continue.*/
    @FXML
    void onActionClose(ActionEvent event) throws IOException {
/*
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "All text fields will be cleared, continue?");

        Optional<ButtonType> result = alert.showAndWait();

 */
        Alerts c = new Confirmation("All text fields will be cleared, continue?", "Unsaved Changes Will Be Lost");

        boolean b = c.generateAlert();

        if (b == true) {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/ViewController/MainScreen.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();

        }
    }

    /**This method allows the user to select a division associated with the selected country. It only displays
     * divisions that share the selected country's country ID.*/
    public void onSelectedCountry(ActionEvent event) {
        Countries countries = countryCombo.getValue();

        ObservableList<Divisions> divisions = DBDivisions.getAllDivisionsByCountry(countries.getCountryId());

        divisionCombo.setItems(divisions);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<Countries> countries = DBCountries.getAllCountries();

        countryCombo.setItems(countries);

/*
        LocalDateTime startdt = LocalDateTime.of(2020, 05, 03, 18, 0 );
        LocalDateTime endDt = LocalDateTime.of(2020, 05, 03, 18, 30 );
        LocalDateTime myDt = LocalDateTime.of(2020, 05, 03, 18, 10 );

        if(myDt.isAfter(startdt) && myDt.isBefore(endDt)) {
            System.out.println(myDt + " is between " + startdt + " and " + endDt );
        }
        else if(myDt.isAfter(startdt))
            System.out.println("Your Date and Time matches" + startdt + "and" + endDt);
        else
            System.out.println("Your Date and Time do not overlap.");

        LocalTime end = LocalTime.MIDNIGHT;
*/
        /*
        LocalTime startTime = LocalTime.of(19, 00);
        LocalTime currentTime = LocalTime.now();
        long timeDifference = ChronoUnit.MINUTES.between(startTime, currentTime);

        System.out.println((timeDifference + -1) * -1);

        long interval = timeDifference;
        System.out.println(interval);


        if(interval > 0 && interval <= 10)
            System.out.println("You have a meeting in " + interval + " minute(s).");
        else if(interval <= 1)
            System.out.println("Event started " + interval * -1 + " minute(s) ago.");

         */


        //startHourCombo.getSelectionModel().select(LocalDateTime.from(LocalTime.of(12, 0)));

        //startHourCombo.setVisibleRowCount(1);

    }

}
