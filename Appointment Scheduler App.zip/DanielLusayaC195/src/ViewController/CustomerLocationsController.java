package ViewController;

import DBAccess.DBCustomer;
import Model.Customers;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/** This class is part of the A3f requirement in the rubric. It allows a user to view customers by location displays
 * the amount of customers for the selected country. It controls the CustomerLocationsScreen FXML user interface. An
 * Observable List for each country is created, then populated with customers located in that country. */
public class CustomerLocationsController implements Initializable {

    Parent scene;
    Stage stage;

    ObservableList<Customers> usCustomers = FXCollections.observableArrayList();
    ObservableList<Customers> ukCustomers = FXCollections.observableArrayList();
    ObservableList<Customers> canadaCustomers = FXCollections.observableArrayList();
    ObservableList<Customers> allCustomers = DBCustomer.getAllCustomers();

    @FXML
    private RadioButton usRBtn;

    @FXML
    private ToggleGroup monthTG;

    @FXML
    private RadioButton ukRBtn;

    @FXML
    private RadioButton canadaRBtn;

    @FXML
    private TableView<Customers> customersTableView;

    @FXML
    private TableColumn<Customers, Integer> customerIdCol;

    @FXML
    private TableColumn<Customers, String> customerNameCol;

    @FXML
    private TableColumn<Customers, String> customerDivisionCol;

    @FXML
    private Label totalCustomersLbl;

    /**This method allows the user to go back to the Main Screen.*/
    @FXML
    void onActionClose(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/ViewController/MainScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**This method displays the customer ID, Name, and Division of customers located in Canada and the amount of customers.
     * A lambda expression is used here to simplify displaying the String amount of customers in Canada. */
    @FXML
    void onCanadaSelected(ActionEvent event) {
        customersTableView.setItems(canadaCustomers);
        totalCustomersLbl.setText(canadaCount());
    }

    /**This method displays the customer ID, Name, and Division of customers located in the U.K. and the amount of customers.
     * A lambda expression is used here to simplify displaying the String amount of customers in the U.K. */
    @FXML
    void onUKSelected(ActionEvent event) {
        customersTableView.setItems(ukCustomers);
        totalCustomersLbl.setText(ukCount());
    }

    /**This method displays the customer ID, Name, and Division of customers located in the U.S. and the amount of customers.
     * A lambda expression is used here to simplify displaying the String amount of customers in the U.S.*/
    @FXML
    void onUSSelected(ActionEvent event) {
        customersTableView.setItems(usCustomers);
        totalCustomersLbl.setText(usCount());
    }

    /**This method displays the amount of customers located in Canada. A lambda expression is used here to simplify
     * displaying the String amount of customers in Canada. */
    public String canadaCount() {
        CustomerLocationsInterface message = () -> String.valueOf(canadaCustomers.size()) + " customer(s)";
        return (message.customerLocations());
    }

    /**This method displays the amount of customers located in the U.K. A lambda expression is used here to simplify
     * displaying the String amount of customers in the U.K. */
    public String ukCount() {
        CustomerLocationsInterface message = () -> String.valueOf(ukCustomers.size()) + " customer(s)";
        return (message.customerLocations());
    }

    /**This method displays the amount of customers located in the U.S. A lambda expression is used here to simplify
     * displaying the String amount of customers in the U.S. */
    public String usCount() {
        CustomerLocationsInterface message = () -> String.valueOf(usCustomers.size()) + " customer(s)";
        return (message.customerLocations());
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        customersTableView.setItems(allCustomers);
        customerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        customerNameCol.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        customerDivisionCol.setCellValueFactory(new PropertyValueFactory<>("divisionName"));

        for (Customers customers : allCustomers) {
            if (customers.getCountryId() == 1)
                usCustomers.add(customers);
        }
        for (Customers customers : allCustomers) {
            if (customers.getCountryId() == 2)
                ukCustomers.add(customers);
        }
        for (Customers customers : allCustomers) {
            if (customers.getCountryId() == 3)
                canadaCustomers.add(customers);
        }
    }
}
