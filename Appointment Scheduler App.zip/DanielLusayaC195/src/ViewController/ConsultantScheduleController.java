package ViewController;

import DBAccess.DBAppointments;
import DBAccess.DBContacts;
import Model.Appointments;
import Model.Contacts;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

/** This class allows a user to view appointments by contact. It controls the ConsultantScheduleScreen FXML user interface.*/
public class ConsultantScheduleController implements Initializable {

    Parent scene;
    Stage stage;

    @FXML
    private TableView<Appointments> appointmentsTableView;

    @FXML
    private TableColumn<Appointments, Integer> appointmentIdCol;

    @FXML
    private TableColumn<Appointments, Integer> userIdCol;

    @FXML
    private TableColumn<Appointments, Integer> customerIdCol;

    @FXML
    private TableColumn<Appointments, String> titleCol;

    @FXML
    private TableColumn<Appointments, String> descriptionCol;

    @FXML
    private TableColumn<Appointments, String> locationCol;

    @FXML
    private TableColumn<Appointments, String> contactCol;

    @FXML
    private TableColumn<Appointments, LocalDateTime> startCol;

    @FXML
    private TableColumn<Appointments, LocalDateTime> endCol;

    @FXML
    private TableColumn<Appointments, String> typeCol;

    @FXML
    private ComboBox<Contacts> consultantCombo;

    /**This method allows the user to go back to the Main Screen.*/
    @FXML
    void onActionClose(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/ViewController/MainScreen.fxml"));
        loader.load();

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**This method allows the user to select a contact and view that contact's appointments. The program searches the
     * database for appointments that match the selected contact's contact ID and adds the results to an
     * Observable List which is displayed in the Table View. */
    public ObservableList<Appointments> getContactAppointments() {

        ObservableList<Appointments> contactAppointments = FXCollections.observableArrayList();
        ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();

        for(Appointments appointments : allAppointments) {

            if(appointments.getAppointmentContactId() == consultantCombo.getValue().getContactId()) {
                contactAppointments.add(appointments);
            }
        }
        return contactAppointments;
    }

    /**This method calls getContactAppointments() when a contact is selected in the combo box by the user. */
    @FXML
    void onSelectedConsultant(ActionEvent event) {

        appointmentsTableView.setItems(getContactAppointments());

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        appointmentsTableView.setItems(DBAppointments.getAllAppointments());

        appointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        customerIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentCustomerId"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("appointmentTitle"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("appointmentDescription"));
        locationCol.setCellValueFactory(new PropertyValueFactory<>("appointmentLocation"));
        userIdCol.setCellValueFactory(new PropertyValueFactory<>("userId"));
        startCol.setCellValueFactory(new PropertyValueFactory<>("appointmentStart"));
        endCol.setCellValueFactory(new PropertyValueFactory<>("appointmentEnd"));
        contactCol.setCellValueFactory(new PropertyValueFactory<>("contactName"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));

        ObservableList<Contacts> contactIds = DBContacts.getAllContacts();

        consultantCombo.setItems(contactIds);

    }
}
