package ViewController;

import DBAccess.DBAppointments;
import DBAccess.DBCustomer;
import Model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.*;
import java.time.temporal.WeekFields;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;

/** This class allows a user to view the main screen of the application. It controls the LoginScreen FXML user interface.
 * The user can add, update, and delete customers and appointments and view various reports.*/
public class MainController implements Initializable {

    Stage stage;
    Parent scene;

    @FXML
    private TableView<Appointments> appointmentsTableView;

    @FXML
    private TableColumn<Appointments, Integer> appointmentIdCol;

    @FXML
    private TableColumn<Customers, Integer> customerIdCol;

    @FXML
    private TableColumn<Appointments, Integer> customerIdCol2;

    @FXML
    private TableColumn<Appointments, String> titleCol;

    @FXML
    private TableColumn<Appointments, String> descriptionCol;

    @FXML
    private TableColumn<Appointments, String> locationCol;

    @FXML
    private TableColumn<Appointments, String> contactCol;

    @FXML
    private TableColumn<Appointments, String> typeCol;

    @FXML
    private TableColumn<Appointments, LocalDateTime> startCol;

    @FXML
    private TableColumn<Appointments, LocalDateTime> endCol;

    @FXML
    private TableView<Customers> customersTableVIew;

    @FXML
    private TableColumn<Customers, String> customerNameCol;

    @FXML
    private TableColumn<Customers, String> addressCol;

    @FXML
    private TableColumn<Customers, String> postalCodeCol;

    @FXML
    private TableColumn<Customers, String> phoneCol;

    @FXML
    private TableColumn<Customers, Integer> divisionNameCol;

    @FXML
    private ToggleGroup appointmentTG;

    @FXML
    private RadioButton allAppointmentsRBtn;

    @FXML
    private RadioButton monthlyAppointmentsRBtn;

    @FXML
    private RadioButton weeklyAppointmentsRBtn;

    @FXML
    private Label errorLbl;

    @FXML
    private Label apptDeleteLbl;

    @FXML
    private Label apptAlertLbl;

    @FXML
    private TextField customerSearch;

    @FXML
    private TextField appointmentSearch;

    @FXML
    void onAppointmentKeyPressed(KeyEvent event) {
        String a = appointmentSearch.getText();
        ObservableList<Appointments> namedAppointments = Appointments.lookupAppointmentStr(a);

        appointmentsTableView.setItems(namedAppointments);
        if(namedAppointments.size()==0)
            apptDeleteLbl.setText("No results");
        else
            apptDeleteLbl.setText("");

        int id = Integer.parseInt(a);
        Appointments appointmentID = Appointments.lookupAppointmentId(id);

        if(appointmentID != null)
            namedAppointments.add(appointmentID);

        if(namedAppointments.size()==0)
            apptDeleteLbl.setText("No results");
        else
            apptDeleteLbl.setText("");

        appointmentsTableView.setItems(namedAppointments);

    }


    @FXML
    void onCustomerKeyPressed(KeyEvent event) {
        String a = customerSearch.getText();
        ObservableList<Customers> namedCustomers = Customers.lookupCustomerStr(a);

        customersTableVIew.setItems(namedCustomers);
        if(namedCustomers.size()==0)
            errorLbl.setText("No results");
        else
            errorLbl.setText("");

        int id = Integer.parseInt(a);
        Customers customerID = Customers.lookupCustomerId(id);

        if(customerID != null)
            namedCustomers.add(customerID);

        if(namedCustomers.size()==0)
            errorLbl.setText("No results");
        else
            errorLbl.setText("");

        customersTableVIew.setItems(namedCustomers);
    }


    /**This method allows the user to go to the AddAppointmentScreen.*/
    @FXML
    void onActionAddAppointment(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/ViewController/AddAppointmentScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**This method allows the user to go to the AddCustomerScreen.*/
    @FXML
    void onActionAddCustomer(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/ViewController/AddCustomerScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**This method allows the user to go to the AppointmentTypesScreen.*/
    @FXML
    void onActionAppointmentTypes(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/ViewController/AppointmentTypesScreen.fxml"));
        loader.load();

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**This method allows the user to go to the ConsultantScheduleScreen.*/
    @FXML
    void onActionConsultantSchedule(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/ViewController/ConsultantScheduleScreen.fxml"));
        loader.load();

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**This method allows the user to delete an appointment. After the user clicks "OK" a label will display notifying
     * the user that the appointment that was deleted.*/
    @FXML
    void onActionDeleteAppointment(ActionEvent event) {

        Alerts c = new Confirmation("Selected appointment will be deleted, continue?", "Confirm Appointment Deletion");

        boolean b = c.generateAlert();

        /*Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Selected appointment will be deleted, continue?");

        Optional<ButtonType> result = alert.showAndWait();

        //if(Confirmation.confirmMessage() == true)
*/
        if(b == true) {


            Appointments selectedAppointment = appointmentsTableView.getSelectionModel().getSelectedItem();

            DBAppointments.deleteAppointmentDB(selectedAppointment.getAppointmentId());
            appointmentsTableView.getItems().remove(selectedAppointment);

            apptDeleteLbl.setText("Appointment #" + selectedAppointment.getAppointmentId() + " " + selectedAppointment.getAppointmentType() + " deleted.");
        }


    }

    /**This method allows the user to delete a customer. If the customer has scheduled appointments, a label will notify
     * the user that the customer's appointments must be deleted first. After the user clicks "OK" a label will display
     * notifying the user that the customer that was deleted.*/
    @FXML
    void onActionDeleteCustomer(ActionEvent event) {
        try {
            Alerts c = new Confirmation("Selected customer will be deleted, continue?", "Confirm Customer Deletion");

            boolean b = c.generateAlert();
/*
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Selected customer will be deleted, continue?");

            Optional<ButtonType> result = alert.showAndWait();


 */
            if(b == true) {

                Customers selectedCustomer = customersTableVIew.getSelectionModel().getSelectedItem();


                if(getCustomerAppointments(selectedCustomer).size() == 0) {
                    DBCustomer.deleteCustomerDB(selectedCustomer.getCustomerId());
                    customersTableVIew.getItems().remove(selectedCustomer);
                    errorLbl.setText("Customer #" + selectedCustomer.getCustomerId() + " deleted.");
                }
                else {
                    errorLbl.setText("Selected customer’s appointment(s) must be deleted.");
                    Alerts w = new Warning("Selected customer’s appointment(s) must be deleted.", "Schedule Error");

                    w.generateAlert();
                }

            }
        }
        catch(NullPointerException e) {

        }

    }

    /**This method allows the user to exit the application.*/
    @FXML
    void onActionLogout(ActionEvent event) {System.exit(0);}

    /**This method allows the user to modify an appointment. The program gets the selected appointment from the Table View
     * and applies the sendAppointment method defined in ModifyAppointmentController.java.*/
    @FXML
    void onActionModifyAppointment(ActionEvent event) throws IOException, SQLException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/ViewController/ModifyAppointmentScreen.fxml"));
        loader.load();

        ModifyAppointmentController ADMController = loader.getController();
        ADMController.sendAppointment(appointmentsTableView.getSelectionModel().getSelectedItem());

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**This method allows the user to modify a customer. The program gets the selected customer from the Table View
     * and applies the sendCustomer method defined in ModifyCustomerController.java.*/
    @FXML
    void onActionModifyCustomer(ActionEvent event) throws IOException, SQLException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/ViewController/ModifyCustomerScreen.fxml"));
        loader.load();

        ModifyCustomerController ADMController = loader.getController();
        ADMController.sendCustomer(customersTableVIew.getSelectionModel().getSelectedItem());

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**This method allows the user to go to the CustomerLocationsScreen.*/
    @FXML
    void onActionCustomerLocations(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/ViewController/CustomerLocationsScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**This method displays all appointments when the All Appointments radio button is selected.*/
    @FXML
    void onMouseClickedAllAppointments(MouseEvent event) { appointmentsTableView.setItems(DBAppointments.getAllAppointments()); }

    /**This method displays all appointments occurring this month when the Monthly Appointments radio button is selected.*/
    @FXML
    void onMouseClickedMonthlyAppointments(MouseEvent event) { appointmentsTableView.setItems(getMonthlyAppointments()); }

    /**This method displays all appointments occurring this week when the Weekly Appointments radio button is selected.*/
    @FXML
    void onMouseClickedWeeklyAppointments(MouseEvent event) {
        appointmentsTableView.setItems(getWeeklyAppointments());
    }

    /**This method retrieves all appointments from the database that occur in the current week. The results are
     * then displayed in the Appointments Table View.*/
    public ObservableList<Appointments> getWeeklyAppointments() {

        ObservableList<Appointments> weeklyAppointments = FXCollections.observableArrayList();
        ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();

        for(Appointments appointments : allAppointments) {
            LocalDate currentDate = LocalDate.now();
            LocalDate compareDate = appointments.getAppointmentStart().toLocalDate();
            WeekFields week = WeekFields.of(Locale.getDefault());

            int compareToday = currentDate.get(week.weekOfWeekBasedYear());
            int compareWeek = compareDate.get(week.weekOfWeekBasedYear());


            if(compareToday == compareWeek) {
                weeklyAppointments.add(appointments);
            }
        }
        return weeklyAppointments;
    }

    /**This method retrieves all appointments from the database that occur in the current week. The results are put into
     * an Observable List and displayed in the Appointments Table View.*/
    public ObservableList<Appointments> getMonthlyAppointments() {

        ObservableList<Appointments> monthlyAppointments = FXCollections.observableArrayList();
        ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();

        for(Appointments appointments : allAppointments) {
            LocalDate currentDate = LocalDate.now();
            LocalDate compareDate = appointments.getAppointmentStart().toLocalDate();
            Month currentMonth = currentDate.getMonth();
            Month compareMonth = compareDate.getMonth();

            if(currentMonth == compareMonth) {
                monthlyAppointments.add(appointments);
            }
        }
        return monthlyAppointments;
    }

    /**This method retrieves all appointments from the database that are associated with the specified customer.
     * The results are added to an Observable List to be summoned when the user is trying to delete appointments.*/
    public ObservableList<Appointments> getCustomerAppointments(Customers selectedCustomers) {

        ObservableList<Appointments> customerAppointments = FXCollections.observableArrayList();
        ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();

        for(Appointments appointments : allAppointments) {

            if(appointments.getAppointmentCustomerId() == selectedCustomers.getCustomerId()) {
                customerAppointments.add(appointments);
            }
        }
        return customerAppointments;
    }

    /**A lambda expression is used here to simplify displaying the alert that an appointment is scheduled in the next
     * 15 minutes as a String. */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        appointmentsTableView.setItems(DBAppointments.getAllAppointments());

        appointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        customerIdCol2.setCellValueFactory(new PropertyValueFactory<>("appointmentCustomerId"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("appointmentTitle"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("appointmentDescription"));
        locationCol.setCellValueFactory(new PropertyValueFactory<>("appointmentLocation"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));
        startCol.setCellValueFactory(new PropertyValueFactory<>("appointmentStart"));
        endCol.setCellValueFactory(new PropertyValueFactory<>("appointmentEnd"));
        contactCol.setCellValueFactory(new PropertyValueFactory<>("contactName"));

        customersTableVIew.setItems(DBCustomer.getAllCustomers());

        customerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        customerNameCol.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
        postalCodeCol.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
        divisionNameCol.setCellValueFactory(new PropertyValueFactory<>("divisionName"));

        allAppointmentsRBtn.setSelected(true);

        AppointmentAlertInterface message = () -> DBAppointments.getAppointmentAlert();
        apptAlertLbl.setText(message.appointmentAlert());
    }
}

