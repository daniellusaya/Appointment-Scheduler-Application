package ViewController;

import DBAccess.DBAppointments;
import Model.Appointments;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/** This class allows a user to view appointments by month and type and displays the amount of appointments for the
 * selected month. It controls the AppointmentTypesScreen FXML user interface. An Observable List for each month is
 * created, then populated with appointments that have start dates on that month. */
public class AppointmentTypesController implements Initializable {

    Parent scene;
    Stage stage;

    ObservableList<Appointments> janAppointments = FXCollections.observableArrayList();
    ObservableList<Appointments> febAppointments = FXCollections.observableArrayList();
    ObservableList<Appointments> marAppointments = FXCollections.observableArrayList();
    ObservableList<Appointments> aprAppointments = FXCollections.observableArrayList();
    ObservableList<Appointments> mayAppointments = FXCollections.observableArrayList();
    ObservableList<Appointments> junAppointments = FXCollections.observableArrayList();
    ObservableList<Appointments> julAppointments = FXCollections.observableArrayList();
    ObservableList<Appointments> augAppointments = FXCollections.observableArrayList();
    ObservableList<Appointments> sepAppointments = FXCollections.observableArrayList();
    ObservableList<Appointments> octAppointments = FXCollections.observableArrayList();
    ObservableList<Appointments> novAppointments = FXCollections.observableArrayList();
    ObservableList<Appointments> decAppointments = FXCollections.observableArrayList();
    ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();

    @FXML
    private RadioButton janRBtn;

    @FXML
    private ToggleGroup monthTG;

    @FXML
    private RadioButton febRBtn;

    @FXML
    private RadioButton marRBtn;

    @FXML
    private RadioButton aprRBtn;

    @FXML
    private RadioButton mayRBtn;

    @FXML
    private RadioButton junRBtn;

    @FXML
    private RadioButton julRBtn;

    @FXML
    private RadioButton augRBtn;

    @FXML
    private RadioButton sepRBtn;

    @FXML
    private RadioButton octRBtn;

    @FXML
    private RadioButton novRBtn;

    @FXML
    private RadioButton decRBtn;

    @FXML
    private TableView<Appointments> appointmentTypeTableView;

    @FXML
    private TableColumn<Appointments, String> appointmentTypeCol;

    @FXML
    private Label totalApptsLbl;

    /**This method displays appointments that occur for the month of April and displays the amount of appointments.*/
    @FXML
    void onAprSelected(ActionEvent event) {
        appointmentTypeTableView.setItems(aprAppointments);
        totalApptsLbl.setText(String.valueOf(aprAppointments.size()) + " appointment(s)");
    }

    /**This method displays appointments that occur for the month of August and displays the amount of appointments.*/
    @FXML
    void onAugSelected(ActionEvent event) {
        appointmentTypeTableView.setItems(augAppointments);
        totalApptsLbl.setText(String.valueOf(augAppointments.size()) + " appointment(s)");
    }

    /**This method displays appointments that occur for the month of December and displays the amount of appointments.*/
    @FXML
    void onDecSelected(ActionEvent event) {
        appointmentTypeTableView.setItems(decAppointments);
        totalApptsLbl.setText(String.valueOf(decAppointments.size()) + " appointment(s)");
    }

    /**This method displays appointments that occur for the month of February and displays the amount of appointments.*/
    @FXML
    void onFebSelected(ActionEvent event) {
        appointmentTypeTableView.setItems(febAppointments);
        totalApptsLbl.setText(String.valueOf(febAppointments.size()) + " appointment(s)");
    }

    /**This method displays appointments that occur for the month of January and displays the amount of appointments.*/
    @FXML
    void onJanSelected(ActionEvent event) {
        appointmentTypeTableView.setItems(janAppointments);
        totalApptsLbl.setText(String.valueOf(janAppointments.size()) + " appointment(s)");
    }

    /**This method displays appointments that occur for the month of July and displays the amount of appointments.*/
    @FXML
    void onJulSelected(ActionEvent event) {
        appointmentTypeTableView.setItems(julAppointments);
        totalApptsLbl.setText(String.valueOf(julAppointments.size()) + " appointment(s)");
    }

    /**This method displays appointments that occur for the month of Jun and displays the amount of appointments.*/
    @FXML
    void onJunSelected(ActionEvent event) {
        appointmentTypeTableView.setItems(junAppointments);
        totalApptsLbl.setText(String.valueOf(junAppointments.size()) + " appointment(s)");
    }

    /**This method displays appointments that occur for the month of March and displays the amount of appointments.*/
    @FXML
    void onMarSelected(ActionEvent event) {
        appointmentTypeTableView.setItems(marAppointments);
        totalApptsLbl.setText(String.valueOf(marAppointments.size()) + " appointment(s)");
    }

    /**This method displays appointments that occur for the month of May and displays the amount of appointments.*/
    @FXML
    void onMaySelected(ActionEvent event) {
        appointmentTypeTableView.setItems(mayAppointments);
        totalApptsLbl.setText(String.valueOf(mayAppointments.size()) + " appointment(s)");
    }

    /**This method displays appointments that occur for the month of November and displays the amount of appointments.*/
    @FXML
    void onNovSelected(ActionEvent event) {
        appointmentTypeTableView.setItems(novAppointments);
        totalApptsLbl.setText(String.valueOf(novAppointments.size()) + " appointment(s)");
    }

    /**This method displays appointments that occur for the month of October and displays the amount of appointments.*/
    @FXML
    void onOctSelected(ActionEvent event) {
        appointmentTypeTableView.setItems(octAppointments);
        totalApptsLbl.setText(String.valueOf(octAppointments.size()) + " appointment(s)");
    }

    /**This method displays appointments that occur for the month of September and displays the amount of appointments.*/
    @FXML
    void onSepSelected(ActionEvent event) {
        appointmentTypeTableView.setItems(sepAppointments);
        totalApptsLbl.setText(String.valueOf(sepAppointments.size()) + " appointment(s)");
    }

    /**This method allows the user to go back to the Main Screen.*/
    @FXML
    void onActionClose(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/ViewController/MainScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        appointmentTypeTableView.setItems(DBAppointments.getAllAppointments());
        appointmentTypeCol.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));

        int totalAppointments = DBAppointments.getAllAppointments().size();

        try {
            for(Appointments appointments : allAppointments) {
                if (appointments.getAppointmentStart().getMonthValue() == 1)
                    janAppointments.add(appointments);
                if (appointments.getAppointmentStart().getMonthValue() == 2)
                    febAppointments.add(appointments);
                if (appointments.getAppointmentStart().getMonthValue() == 3)
                    marAppointments.add(appointments);
                if (appointments.getAppointmentStart().getMonthValue() == 4)
                    aprAppointments.add(appointments);
                if (appointments.getAppointmentStart().getMonthValue() == 5)
                    mayAppointments.add(appointments);
                if (appointments.getAppointmentStart().getMonthValue() == 6)
                    junAppointments.add(appointments);
                if (appointments.getAppointmentStart().getMonthValue() == 7)
                    julAppointments.add(appointments);
                if (appointments.getAppointmentStart().getMonthValue() == 8)
                    augAppointments.add(appointments);
                if (appointments.getAppointmentStart().getMonthValue() == 9)
                    sepAppointments.add(appointments);
                if (appointments.getAppointmentStart().getMonthValue() == 10)
                    octAppointments.add(appointments);
                if (appointments.getAppointmentStart().getMonthValue() == 11)
                    novAppointments.add(appointments);
                if (appointments.getAppointmentStart().getMonthValue() == 12)
                    decAppointments.add(appointments);
            }
        }
        catch (NullPointerException e) {
        }

        }
    }

