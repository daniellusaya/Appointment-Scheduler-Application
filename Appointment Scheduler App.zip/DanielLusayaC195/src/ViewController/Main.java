package ViewController;

import Database.DBConnection;
import Model.Confirmation;
import Model.Warning;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.*;
import java.time.*;
import java.util.Locale;
import java.util.ResourceBundle;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("/ViewController/LoginScreen.fxml"));
        primaryStage.setTitle("Scheduling Software");
        primaryStage.setScene(new Scene(root, 600, 400));
        primaryStage.show();
    }


    public static void main(String[] args) throws SQLException, IOException {



        DBConnection.startConnection();
        Connection conn = DBConnection.getConnection();

        LocalDate myLD = LocalDate.of(2021, 5, 6);
        LocalTime myLT = LocalTime.of(9, 35);
        LocalDateTime myLDT = LocalDateTime.of(myLD, myLT);
        ZoneId myZoneId = ZoneId.systemDefault();
        ZonedDateTime myZDT = ZonedDateTime.of(myLDT, myZoneId);

        System.out.println("User time: " + myZDT);

        ZoneId utcZoneId = ZoneId.of("UTC");
        ZonedDateTime utcZDT = ZonedDateTime.ofInstant(myZDT.toInstant(), utcZoneId);

        myZDT = ZonedDateTime.ofInstant(utcZDT.toInstant(), myZoneId);

        System.out.println("User time to UTC: " + utcZDT);

        System.out.println("UTC time to user: " + myZDT);



        System.out.println(ZoneId.systemDefault());

        //ZoneId.getAvailableZoneIds().stream().filter(z->z.contains("America")).sorted().forEach(System.out::println);

        Locale france = new Locale("fr", "FR");
        Locale espanol = new Locale("es", "ES");
        Locale german = new Locale("de", "DE");
        Locale english = new Locale("en", "EN");
/*
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter a language(es, de, fr, en)");
        String languageCode = keyboard.nextLine();

        if(languageCode.equals("fr"))
            Locale.setDefault(france);
        else if(languageCode.equals("es"))
            Locale.setDefault(espanol);
        else if(languageCode.equals("de"))
            Locale.setDefault(german);
        else if(languageCode.equals("en"))
            Locale.setDefault(english);
        else {
            System.out.println("Language not supported.");
            System.exit(0);
        }
*/
        ResourceBundle rb = ResourceBundle.getBundle("Model/Nat", Locale.getDefault());

        //GeneralInterface square = n -> n * n;

        //GeneralInterface message = s -> System.out.println("hello agen " + s);
        //GeneralInterface sum = (n1, n2) -> n1 + n2;
        //System.out.println(sum.calculateSum(5, 10));
        //GeneralInterface message = () -> System.out.println("hello agen ");
        //message.displayMessage();
        //GeneralInterface square = n -> {
          //  int result = n * n;
            //return result;
        //};
        //System.out.println(square.calculateSquare(6));

//        final int num = 50;
  //      CustomerLocationsInterface square = n -> n * n;
    //    System.out.println(square.calculateSquare(num));

        //message.displayMessage("Name");
        //if(Locale.getDefault().getLanguage().equals("de") || Locale.getDefault().getLanguage().equals("fr"))

        launch(args);
        DBConnection.closeConnection();
    }
}

        //String insertStatement = "INSERT INTO countries(Country, Create_Date, Created_By, Last_Updated_By) VALUES(?, ?, ?, ?)";
        //String updateStatement = "UPDATE countries SET Country = ?, Created_By = ? WHERE Country = ?";
        //String deleteStatement = "DELETE FROM countries WHERE Country = ?";
        //String selectStatement = "SELECT * FROM countries";

        //DBQuery.setPreparedStatement(conn, insertStatement);
        //DBQuery.setPreparedStatement(conn, updateStatement);
        //DBQuery.setPreparedStatement(conn, deleteStatement);
        //DBQuery.setPreparedStatement(conn, selectStatement);

        //PreparedStatement ps = DBQuery.getPreparedStatement();

//        String Country;
        //String Country, newCountry, Created_By;
/*        String Country;
        String Create_Date = "2021-04-25 00:00:00";
        String Created_By = "admin";
        String Last_Updated_By = "admin";
*/
//        Scanner keyboard = new Scanner(System.in);

//        System.out.print("Enter a country to delete: ");
//        Country = keyboard.nextLine();
/*
        //System.out.print("Enter a country: ");
        System.out.print("Enter a country to update: ");
        Country = keyboard.nextLine();

        System.out.print("Enter a new country: ");
        newCountry = keyboard.nextLine();

        System.out.print("Enter user: ");
        Created_By = keyboard.nextLine();
 */
//        ps.setString(1, Country);
/*
        ps.setString(1, newCountry);
        ps.setString(2, Created_By);
        ps.setString(3, Country);

 */
/*
        ps.setString(1, Country);
        ps.setString(2, Create_Date);
        ps.setString(3, Created_By);
        ps.setString(4, Last_Updated_By);

        ps.execute();

        ResultSet rs = ps.getResultSet();

        while (rs.next()) {
            int Country_ID = rs.getInt("Country_ID");
            String Country = rs.getString("Country");
            LocalDate date = rs.getDate("Create_Date").toLocalDate();
            LocalTime time = rs.getTime("Create_Date").toLocalTime();
            String Created_By = rs.getString("Created_By");
            LocalDateTime Last_Update = rs.getTimestamp("Last_Update").toLocalDateTime();

            System.out.println(Country_ID + " | " + Country + " | " + date + " | " + time + " | " + Created_By + " | " + Last_Update);
        }
*/
/*        if(ps.getUpdateCount() > 0)
            System.out.println(ps.getUpdateCount() + " row(s) affected.");
        else
            System.out.println("No change.");
*/
/*        Connection conn = DBConnection.getConnection();
        //DBCountries.checkDateConversion();

        DBQuery.setStatement(conn);
        Statement statement = DBQuery.getStatement();

        String Country, Create_Date, Created_By, Last_Updated_By;
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter a country: ");

        Country = keyboard.nextLine();
        Create_Date = "2021-04-25 00:00:00";
        Created_By = "admin";
        Last_Updated_By = "admin";

        if(Country.contains("'"))
            Country = Country.replace("'", "\\'");

        String insertStatement = "INSERT INTO countries(Country, Create_Date, Created_By, Last_Updated_By)" +
                "VALUES(" +
                "'" + Country + "'," +
                "'" + Create_Date + "'," +
                "'" + Created_By + "'," +
                "'" + Last_Updated_By + "'" +
                ")";

*/
/*
        try {
            statement.execute(insertStatement);

            if(statement.getUpdateCount() > 0)
                System.out.println(statement.getUpdateCount() + " row(s) affected.");
            else
                System.out.println("No change.");
*/
            /*ResultSet rs = statement.getResultSet();

            while (rs.next()) {
                int Country_ID = rs.getInt("Country_ID");
                String Country = rs.getString("Country");
                LocalDate date = rs.getDate("Create_Date").toLocalDate();
                LocalTime time = rs.getTime("Create_Date").toLocalTime();
                String Created_By = rs.getString("Created_By");
                LocalDateTime Last_Update = rs.getTimestamp("Last_Update").toLocalDateTime();

                System.out.println(Country_ID + " | " + Country + " | " + date + " | " + time + " | " + Created_By + " | " + Last_Update);
            }*/
/*        }

        catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
*/
        //String insertStatement = "INSERT INTO countries(Country, Create_Date, Created_By, Last_Updated_By) VALUES('US', '2021-04-24 00:00:00', 'admin', 'admin')";
/*
        String Country = "Canada";
        String Create_Date = "2021-04-25 00:00:00";
        String Created_By = "admin";
        String Last_Updated_By = "admin";

        String insertStatement = "INSERT INTO countries(Country, Create_Date, Created_By, Last_Updated_By)" +
                "VALUES(" +
                "'" + Country + "'," +
                "'" + Create_Date + "'," +
                "'" + Created_By + "'," +
                "'" + Last_Updated_By + "'" +
                ")";
*/
/*
        //String updateStatement = "UPDATE countries SET Country = 'Japan' WHERE Country = 'Canada'";

        String deleteStatement = "DELETE FROM countries WHERE Created_By = 'admin'";

        //statement.execute(updateStatement);

        statement.execute(deleteStatement);

        //statement.execute(insertStatement);


        if(statement.getUpdateCount() > 0)
            System.out.println(statement.getUpdateCount() + " row(s) affected.");
        else
            System.out.println("No change.");
*/
