package ViewController;

/** This class is lambda class #2 for displaying a string in CustomerLocationsController.Java. */
public interface CustomerLocationsInterface {

    String customerLocations();

}
