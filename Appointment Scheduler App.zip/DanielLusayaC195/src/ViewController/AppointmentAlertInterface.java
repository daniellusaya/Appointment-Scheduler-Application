package ViewController;

/** This class is lambda class #1 for displaying a string in LoginController.Java. */
public interface AppointmentAlertInterface {
    String appointmentAlert();
}
