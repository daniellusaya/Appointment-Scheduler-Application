package ViewController;

import DBAccess.DBAppointments;
import DBAccess.DBContacts;
import DBAccess.DBCustomer;
import DBAccess.DBUsers;
import Model.*;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.*;
import java.util.Optional;
import java.util.ResourceBundle;

/** This class allows a user to add an appointment. It controls the AddAppointmentScreen FXML user interface. */
public class AddAppointmentController implements Initializable {

    Stage stage;
    Parent scene;

    @FXML
    private Label appointmentIdLbl;

    @FXML
    private Label errorLbl;

    @FXML
    private TextField titleTxt;

    @FXML
    private TextField descriptionTxt;

    @FXML
    private TextField locationTxt;

    @FXML
    private TextField typeTxt;

    @FXML
    private ComboBox<Users> userIdCombo;

    @FXML
    private ComboBox<Customers> customerIdCombo;

    @FXML
    private ComboBox<Contacts> contactCombo;

    @FXML
    private DatePicker dateDP;

    @FXML
    private ComboBox<LocalTime> startHourCombo;

    @FXML
    private ComboBox<LocalTime> endHourCombo;

    /**This method allows the user to add an appointment. User input for text fields Title, Description, Location, and Type,
     * for combo boxes User, Customer, and Contact, and for Date, Start Time, and End Time are added to the appointment.
     * After confirming the selected customer has no existing appointments that conflict with the user's inputted times,
     * these values are entered into the database as a new appointment using the addAppointmentDB method from the
     * DBAppointments class.*/
    @FXML
    void onActionAddAppointment(ActionEvent event) throws IOException {

        try {
            String appointmentTitle = titleTxt.getText();
            String appointmentDescription = descriptionTxt.getText();
            String appointmentLocation = locationTxt.getText();
            String appointmentType = typeTxt.getText();
            LocalDate appointmentDate = dateDP.getValue();
            LocalTime appointmentStart = startHourCombo.getValue();
            LocalTime appointmentEnd = endHourCombo.getValue();
            Users user = userIdCombo.getValue();
            Contacts contact = contactCombo.getValue();
            Customers customer = customerIdCombo.getValue();

            LocalDateTime startLDT = LocalDateTime.of(appointmentDate, appointmentStart);
            LocalDateTime endLDT = LocalDateTime.of(appointmentDate, appointmentEnd);

            ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();
            for (Appointments appointments : allAppointments) {
                LocalDateTime existingStart = appointments.getAppointmentStart();
                LocalDateTime existingEnd = appointments.getAppointmentEnd();
                int selectedCustomerId = customerIdCombo.getValue().getCustomerId();

                if(selectedCustomerId == appointments.getAppointmentCustomerId()) {

                    if (startLDT.isAfter(existingStart.minusMinutes(1)) && startLDT.isBefore(existingEnd)
                            || endLDT.isAfter(existingStart) && endLDT.isBefore(existingEnd.plusMinutes(1))
                            || startLDT.isBefore(existingStart) && endLDT.isAfter(existingEnd)) {
                        errorLbl.setText("Appointment overlap detected: " + customerIdCombo.getValue() + " is currently scheduled for \n" + appointments.getAppointmentType()
                                + " at " + appointments.getAppointmentStart() + " - " + appointments.getAppointmentEnd().toLocalTime() + ". Please adjust date and times.");
                        return;
                    }
                }

            }
            DBAppointments.addAppointmentDB(appointmentTitle, appointmentDescription, appointmentLocation,
                    appointmentType, Timestamp.valueOf(startLDT), Timestamp.valueOf(endLDT),
                    contact.getContactId(), customer.getCustomerId(), user.getUserId());

            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/ViewController/MainScreen.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();

        }
        catch (NullPointerException e) {

        }

    }

    /**This method allows the user to go back to the Main Screen. It warns the user that all text fields will be cleared
     * if the user clicks continue.*/
    @FXML
    void onActionClose(ActionEvent event) throws IOException {
/*
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "All text fields will be cleared, continue?");

        Optional<ButtonType> result = alert.showAndWait();

 */
        Alerts c = new Confirmation("All text fields will be cleared, continue?", "Unsaved Changes Will Be Lost");

        boolean b = c.generateAlert();

        if (b == true) {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/ViewController/MainScreen.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();

        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<Customers> customerIds = DBCustomer.getAllCustomers();
        ObservableList<Contacts> contactIds = DBContacts.getAllContacts();
        ObservableList<Users> userIds = DBUsers.getAllUsers();

        customerIdCombo.setItems(customerIds);
        contactCombo.setItems(contactIds);
        userIdCombo.setItems(userIds);

        ZoneId userZoneId = ZoneId.systemDefault();
        ZoneId utcZoneId = ZoneId.of("UTC");

        LocalDate utcDate = LocalDate.of(2021, 5, 7);

        LocalTime utcOpen = LocalTime.of(12, 0);
        LocalTime utcClose = LocalTime.of(2, 0);

        LocalDateTime utcOpenLDT = LocalDateTime.of(2021, 5, 7, 12, 0);
        LocalDateTime utcCloseLDT = LocalDateTime.of(2021, 5, 7, 2, 0);

        ZonedDateTime utcOpenZDT = ZonedDateTime.of(utcOpenLDT, utcZoneId);
        ZonedDateTime utcCloseZDT = ZonedDateTime.of(utcCloseLDT, utcZoneId);

        ZonedDateTime userOpenZDT = ZonedDateTime.ofInstant(utcOpenZDT.toInstant(), userZoneId);
        ZonedDateTime userCloseZDT = ZonedDateTime.ofInstant(utcCloseZDT.toInstant(), userZoneId);

        LocalDateTime userOpenLDT = LocalDateTime.ofInstant(userOpenZDT.toInstant(), userZoneId);
        LocalDateTime userCloseLDT = LocalDateTime.ofInstant(userCloseZDT.toInstant(), userZoneId);


        LocalTime startTime = userOpenLDT.toLocalTime();
        LocalTime endTime = userCloseLDT.toLocalTime();

        while(startTime.isBefore((endTime.plusSeconds(1)))) {
            startHourCombo.getItems().add(startTime);
            endHourCombo.getItems().add(startTime);
            startTime = startTime.plusMinutes(15);
        }


        //startHourCombo.getSelectionModel().select(LocalDateTime.from(LocalTime.of(12, 0)));

        //startHourCombo.setVisibleRowCount(1);

    }
}

