package ViewController;

import DBAccess.DBCountries;
import DBAccess.DBCustomer;
import DBAccess.DBDivisions;
import Database.DBConnection;
import Model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

/** This class allows a user to modify a customer. It controls the ModifyCustomerScreen FXML user interface. */
public class ModifyCustomerController implements Initializable {

    Parent scene;
    Stage stage;

    @FXML
    private Label customerIdLbl;

    @FXML
    private TextField addressTxt;

    @FXML
    private TextField zipCodeTxt;

    @FXML
    private TextField phoneNumberTxt;

    @FXML
    private TextField customerNameTxt;

    @FXML
    private ComboBox<Countries> countryCombo;

    @FXML
    private ComboBox<Divisions> divisionCombo;

    /**This method allows the user to go back to the Main Screen. It warns the user that all text fields will be cleared
     * if the user clicks continue.*/
    @FXML
    void onActionClose(ActionEvent event) throws IOException {
/*
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "All unsaved changes will be deleted, continue?");

        Optional<ButtonType> result = alert.showAndWait();

 */
        Alerts c = new Confirmation("All text fields will be cleared, continue?", "Unsaved Changes Will Be Lost");

        boolean b = c.generateAlert();

        if (b == true) {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/ViewController/MainScreen.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();

        }
    }

    /**This method allows the user to modify a customer. User input for text fields Name, address, postal code, and
     * phone number and for combo boxes country and division are updated to the customer. These values are entered into
     * the database, updating all of the customer's values except for the ID using the modifyCustomerDB method from the
     * DBCustomers class.*/
    @FXML
    void onActionModifyCustomer(ActionEvent event) throws IOException {

        try {
            String customerName = customerNameTxt.getText();
            String customerAddress = addressTxt.getText();
            String customerPhone = phoneNumberTxt.getText();
            String customerPostalCode = zipCodeTxt.getText();
            Countries countries = countryCombo.getValue();
            Divisions divisions = divisionCombo.getValue();
            String customerId = customerIdLbl.getText();

            DBCustomer.modifyCustomerDB(customerName, customerAddress, customerPostalCode,
                    customerPhone, divisions.getDivisionId(), customerId);


            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/ViewController/MainScreen.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }
        catch (NullPointerException e) {
            e.printStackTrace();
        }
    }

    /**This method sends the selected customer's data to the next screen so that the next screen's containers display
     * pre-populated data.*/
    public void sendCustomer(Customers customers) throws SQLException {
        customerIdLbl.setText(String.valueOf(customers.getCustomerId()));
        customerNameTxt.setText(customers.getCustomerName());
        addressTxt.setText(customers.getAddress());
        zipCodeTxt.setText(customers.getPostalCode());
        phoneNumberTxt.setText(customers.getPhone());
        countryCombo.setValue(getCountryName(customers.getCountryId()));
        divisionCombo.setValue(getDivisionName(customers.getDivisionId()));
    }

    /**This method retrieves the country name based on the specified country ID.*/
    public static Countries getCountryName(int countryId) throws SQLException {
        ObservableList<Countries> countriesList = FXCollections.observableArrayList();

        try {
            String sqlcountries = "SELECT * FROM countries WHERE Country_ID = ?";
            PreparedStatement pscountries = DBConnection.getConnection().prepareStatement(sqlcountries);
            pscountries.setInt(1, countryId);
            ResultSet rscountries = pscountries.executeQuery();

            while(rscountries.next()) {
                int countryID = rscountries.getInt("Country_ID");
                String countryName = rscountries.getString("Country");

                Countries countries = new Countries(countryID, countryName);
                countriesList.add(countries);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return countriesList.get(0);
    }

    /**This method retrieves the division's name based on the specified division ID.*/
    public static Divisions getDivisionName(int divisionId) throws SQLException {

        ObservableList<Divisions> divisionsList = FXCollections.observableArrayList();

        try {
            String sqlDivisions = "SELECT * FROM first_level_divisions WHERE Division_ID = ?";
            PreparedStatement psdiv = DBConnection.getConnection().prepareStatement(sqlDivisions);
            psdiv.setInt(1, divisionId);
            ResultSet rsdiv = psdiv.executeQuery();

            while(rsdiv.next()) {
                int divisionID = rsdiv.getInt("Division_ID");
                String divisionName = rsdiv.getString("Division");
                int countryId = rsdiv.getInt("COUNTRY_ID");

                Divisions divisions = new Divisions(divisionID, divisionName, countryId);
                divisionsList.add(divisions);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return divisionsList.get(0);
    }

    /**This method allows the user to select a division associated with the selected country. It only displays
     * divisions that share the selected country's country ID.*/
    public void onSelectedCountry(ActionEvent event) {
        Countries countries = countryCombo.getValue();

        ObservableList<Divisions> divisions = DBDivisions.getAllDivisionsByCountry(countries.getCountryId());

        divisionCombo.setItems(divisions);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<Countries> countries = DBCountries.getAllCountries();

        countryCombo.setItems(countries);
    }
}
