package ViewController;

import Model.Confirmation;
import Model.Warning;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Locale;
import java.util.ResourceBundle;

/** This class allows a user to log in to the application. It controls the LoginScreen FXML user interface.*/
public class LoginController implements Initializable {

    Stage stage;
    Parent scene;

    @FXML
    private Label loginLbl;

    @FXML
    private Label locationLbl;

    @FXML
    private Label usernameLbl;

    @FXML
    private Label passwordLbl;

    @FXML
    private Button loginBtnLbl;

    @FXML
    private Button exitBtnLbl;

    @FXML
    private Label errorLbl;

    @FXML
    private TextField usernameTxt;

    @FXML
    private TextField passwordTxt;

    /**This method allows the user to exit the application.*/
    @FXML
    void onActionExit(ActionEvent event) {System.exit(0);}

    /** A lambda expression is used here to simplify displaying the user's location as a String in a label.*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ResourceBundle rb = ResourceBundle.getBundle("Model/Nat", Locale.getDefault());


        if(Locale.getDefault().getLanguage().equals("fr")) {
            usernameLbl.setText(rb.getString("Username"));
            passwordLbl.setText(rb.getString("Password"));
            loginLbl.setText(rb.getString("Login"));
            loginBtnLbl.setText(rb.getString("Login"));
            exitBtnLbl.setText(rb.getString("Exit"));
        }

        AppointmentAlertInterface message = () -> String.valueOf(ZoneId.systemDefault());
        locationLbl.setText(message.appointmentAlert());
    }

    /** This method allows a user to log in to the application. The program gets and displays the user's location. If the user's
     * default language is set to French, all labels and alert messages are set translated to French. A log of all log in
     * attempts is located in src/root/login_activity.txt. The user must use "test" as username and password.
     * A lambda expression is used here to simplify displaying the amount of customers in Canada*/
  @FXML
    void onActionLogin(ActionEvent event) throws IOException {
        try {

            ResourceBundle rb = ResourceBundle.getBundle("Model/Nat", Locale.getDefault());

            String fileName = "src/root/login_activity.txt", attempt;

            FileWriter fwriter = new FileWriter(fileName, true);

            PrintWriter outputFile = new PrintWriter(fwriter);

            if (usernameTxt.getText().equals("test") && passwordTxt.getText().equals("test")) {
                attempt = "Login Successful     Username: " + usernameLbl.getText()+ "       Date: " + LocalDate.now() + "     Time: " + LocalTime.now();
                outputFile.println(attempt);
                outputFile.close();

                stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/ViewController/MainScreen.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();
            }
            else {
                attempt = "Login Failed     Username: " + usernameLbl.getText()+ "       Date: " + LocalDate.now() + "     Time: " + LocalTime.now();
                outputFile.println(attempt);
                outputFile.close();

                Locale.getDefault().getLanguage();
                errorLbl.setText(rb.getString("Invalid") + " " + rb.getString("Credentials"));
            }
        }
        catch(NullPointerException e) {

        }
    }
}
