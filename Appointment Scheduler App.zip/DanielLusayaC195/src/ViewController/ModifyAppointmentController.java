package ViewController;

import DBAccess.DBAppointments;
import DBAccess.DBContacts;
import DBAccess.DBCustomer;
import DBAccess.DBUsers;
import Database.DBConnection;
import Model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.*;
import java.util.Optional;
import java.util.ResourceBundle;

/** This class allows a user to modify an appointment. It controls the ModifyAppointmentsScreen FXML user interface. */
public class ModifyAppointmentController implements Initializable {

    Parent scene;
    Stage stage;

    @FXML
    private Label appointmentIdLbl;

    @FXML
    private TextField titleTxt;

    @FXML
    private TextField descriptionTxt;

    @FXML
    private TextField locationTxt;

    @FXML
    private TextField typeTxt;

    @FXML
    private ComboBox<Users> userIdCombo;

    @FXML
    private ComboBox<Customers> customerIdCombo;

    @FXML
    private ComboBox<Contacts> contactCombo;

    @FXML
    private DatePicker dateDP;

    @FXML
    private ComboBox<LocalTime> startHourCombo;

    @FXML
    private ComboBox<LocalTime> endHourCombo;

    @FXML
    private Label errorLbl;

    ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();

    /**This method allows the user to go back to the Main Screen. It warns the user that all text fields will be cleared
     * if the user clicks continue.*/
    @FXML
    void onActionClose(ActionEvent event) throws IOException {
/*
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "All unsaved changes will be deleted, continue?");

        Optional<ButtonType> result = alert.showAndWait();

 */
        Alerts c = new Confirmation("All text fields will be cleared, continue?", "Unsaved Changes Will Be Lost");

        boolean b = c.generateAlert();

        if (b == true) {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/ViewController/MainScreen.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();

        }
    }

    /**This method allows the user to modify an appointment. User input for text fields Title, Description, Location, and Type,
     * for combo boxes User, Customer, and Contact, and for Date, Start Time, and End Time are updated to the appointment.
     * After confirming the selected customer has no other existing appointments that conflict with the user's inputted times,
     * these values are entered into the database, updating all of the appointment's values except for the ID using the
     * modifyAppointmentDB method from the DBAppointments class.*/
    @FXML
    void onActionModifyAppointment(ActionEvent event) throws IOException {

        String appointmentId = appointmentIdLbl.getText();
        String appointmentTitle = titleTxt.getText();
        String appointmentDescription = descriptionTxt.getText();
        String appointmentLocation = locationTxt.getText();
        String appointmentType = typeTxt.getText();
        LocalDate appointmentDate = dateDP.getValue();
        LocalTime appointmentStart = startHourCombo.getValue();
        LocalTime appointmentEnd = endHourCombo.getValue();
        Users user = userIdCombo.getValue();
        Contacts contact = contactCombo.getValue();
        Customers customer = customerIdCombo.getValue();

        LocalDateTime startLDT = LocalDateTime.of(appointmentDate, appointmentStart);
        LocalDateTime endLDT = LocalDateTime.of(appointmentDate, appointmentEnd);

        removeCurrentAppointment();

        for (Appointments appointments : allAppointments) {

            LocalDateTime existingStart = appointments.getAppointmentStart();
            LocalDateTime existingEnd = appointments.getAppointmentEnd();
            int selectedCustomerId = customerIdCombo.getValue().getCustomerId();

            if (selectedCustomerId == appointments.getAppointmentCustomerId()) {

                if (startLDT.isAfter(existingStart.minusMinutes(1)) && startLDT.isBefore(existingEnd)
                        || endLDT.isAfter(existingStart) && endLDT.isBefore(existingEnd.plusMinutes(1))
                        || startLDT.isBefore(existingStart) && endLDT.isAfter(existingEnd.plusMinutes(1))) {
                    errorLbl.setText("Appointment overlap detected: " + customerIdCombo.getValue() + " is currently scheduled for \n" + appointments.getAppointmentType()
                            + " at " + appointments.getAppointmentStart() + " - " + appointments.getAppointmentEnd().toLocalTime() + ". Please adjust date and times.");
                    return;
                }
            }
        }
        DBAppointments.modifyAppointmentDB(appointmentId, appointmentTitle, appointmentDescription, appointmentLocation,
                appointmentType, Timestamp.valueOf(startLDT), Timestamp.valueOf(endLDT),
                contact.getContactId(),customer.getCustomerId(), user.getUserId());

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/ViewController/MainScreen.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**This method is used to exclude the selected appointment from being counted as an existing appointment in the
     * onActionModifyAppointment method. This makes the program skip the selected appointment which would cause an overlap
     * if only the start or end time is adjusted.*/
    public boolean removeCurrentAppointment() {
        ObservableList<Appointments> currentAppointment = FXCollections.observableArrayList();
        String appointmentId = appointmentIdLbl.getText();
        int removeId = Integer.parseInt(appointmentId);

        for(Appointments appointments : allAppointments) {
            if(removeId == appointments.getAppointmentId())
                currentAppointment.add(appointments);
        }
        return allAppointments.removeAll(currentAppointment);
    }

    /**This method sends the selected appointment's data to the next screen so that the next screens container's display
     * pre-populated data.*/
    public void sendAppointment(Appointments appointments) throws SQLException {
        appointmentIdLbl.setText(String.valueOf(appointments.getAppointmentId()));
        titleTxt.setText(appointments.getAppointmentTitle());
        descriptionTxt.setText(appointments.getAppointmentDescription());
        locationTxt.setText(appointments.getAppointmentLocation());
        typeTxt.setText(appointments.getAppointmentType());
        startHourCombo.setValue(appointments.getAppointmentStart().toLocalTime());
        endHourCombo.setValue(appointments.getAppointmentEnd().toLocalTime());
        dateDP.setValue(appointments.getAppointmentStart().toLocalDate());
        customerIdCombo.setValue(getCustomerName(appointments.getAppointmentCustomerId()));
        userIdCombo.setValue(getUsername(appointments.getUserId()));
        contactCombo.setValue(getContactName(appointments.getAppointmentContactId()));
    }
    /**This method retrieves the customer's name based on the specified customer ID.*/
    public static Customers getCustomerName(int customerId) throws SQLException {

        ObservableList<Customers> customersList = FXCollections.observableArrayList();

        try {
            String sqlcustomer = "SELECT * FROM customers WHERE Customer_ID = ?";
            PreparedStatement pscust = DBConnection.getConnection().prepareStatement(sqlcustomer);
            pscust.setInt(1, customerId);
            ResultSet rscust = pscust.executeQuery();

            while(rscust.next()) {
                int customerID = rscust.getInt("Customer_ID");
                String customerName = rscust.getString("Customer_Name");
                String customerAddress = rscust.getString("Address");
                String customerPostalCode = rscust.getString("Postal_Code");
                String customerPhone = rscust.getString("Phone");
                int divisionId = 0;
                int countryId = 0;
                String divisionName = "";

                Customers customer = new Customers(customerID, customerName, customerAddress, customerPostalCode,
                        customerPhone, divisionId, countryId, divisionName);
                customersList.add(customer);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return customersList.get(0);
    }

    /**This method retrieves the user's name based on the specified user ID.*/
    public static Users getUsername(int userId) throws SQLException {

        ObservableList<Users> usersList = FXCollections.observableArrayList();

        try {
            String sqluser = "SELECT * FROM users WHERE User_ID = ?";
            PreparedStatement psu = DBConnection.getConnection().prepareStatement(sqluser);
            psu.setInt(1, userId);
            ResultSet rsu = psu.executeQuery();

            while(rsu.next()) {
                int userID = rsu.getInt("User_ID");
                String userName = rsu.getString("User_Name");
                String password = rsu.getString("Password");

                Users user = new Users(userID, userName, password);
                usersList.add(user);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return usersList.get(0);
    }

    /**This method retrieves the contact's name based on the specified contact ID.*/
    public static Contacts getContactName(int contactId) throws SQLException {

        ObservableList<Contacts> contactsList = FXCollections.observableArrayList();

        try {
            String sqlcontacts = "SELECT * FROM contacts WHERE Contact_ID = ?";
            PreparedStatement pscon = DBConnection.getConnection().prepareStatement(sqlcontacts);
            pscon.setInt(1, contactId);
            ResultSet rscon = pscon.executeQuery();

            while(rscon.next()) {
                int contactID = rscon.getInt("Contact_ID");
                String contactName = rscon.getString("Contact_Name");
                String contactEmail = rscon.getString("Email");

                Contacts contact = new Contacts(contactID, contactName, contactEmail);
                contactsList.add(contact);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return contactsList.get(0);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ObservableList<Customers> customerIds = DBCustomer.getAllCustomers();
        ObservableList<Contacts> contactIds = DBContacts.getAllContacts();
        ObservableList<Users> userIds = DBUsers.getAllUsers();

        customerIdCombo.setItems(customerIds);
        contactCombo.setItems(contactIds);
        userIdCombo.setItems(userIds);

        ZoneId userZoneId = ZoneId.systemDefault();
        ZoneId utcZoneId = ZoneId.of("UTC");

        LocalDate utcDate = LocalDate.of(2021, 5, 7);

        LocalTime utcOpen = LocalTime.of(12, 0);
        LocalTime utcClose = LocalTime.of(2, 0);

        LocalDateTime utcOpenLDT = LocalDateTime.of(2021, 5, 7, 12, 0);
        LocalDateTime utcCloseLDT = LocalDateTime.of(2021, 5, 7, 2, 0);

        ZonedDateTime utcOpenZDT = ZonedDateTime.of(utcOpenLDT, utcZoneId);
        ZonedDateTime utcCloseZDT = ZonedDateTime.of(utcCloseLDT, utcZoneId);

        ZonedDateTime userOpenZDT = ZonedDateTime.ofInstant(utcOpenZDT.toInstant(), userZoneId);
        ZonedDateTime userCloseZDT = ZonedDateTime.ofInstant(utcCloseZDT.toInstant(), userZoneId);

        LocalDateTime userOpenLDT = LocalDateTime.ofInstant(userOpenZDT.toInstant(), userZoneId);
        LocalDateTime userCloseLDT = LocalDateTime.ofInstant(userCloseZDT.toInstant(), userZoneId);


        LocalTime startTime = userOpenLDT.toLocalTime();
        LocalTime endTime = userCloseLDT.toLocalTime();

        while(startTime.isBefore((endTime.plusSeconds(1)))) {
            startHourCombo.getItems().add(startTime);
            endHourCombo.getItems().add(startTime);
            startTime = startTime.plusMinutes(15);
        }

    }
}
