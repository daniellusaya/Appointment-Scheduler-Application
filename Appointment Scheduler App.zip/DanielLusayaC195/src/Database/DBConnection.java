package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * This class establishes a connection with the SQL database WJ07NBh. It uses the username, password IP address, and
 * mySQL JDBC driver to connect, get connection, and close the connection.
 */
public class DBConnection {

    private static final String protocol = "jdbc";
    private static final String vendorName = ":mysql:";
    private static final String ipAddress = "//wgudb.ucertify.com/WJ07NBh";
    private static final String dbName = "WJ07NBh";

    private static final String jdbcURL = protocol + vendorName + ipAddress;
    private static final String MYSQLJDBCDriver = "com.mysql.jdbc.Driver";
    private static Connection conn = null;

    private static final String username = "U07NBh";
    private static String password = "53689074457";

    public static Connection startConnection()
    {
        try {
            Class.forName(MYSQLJDBCDriver);
            conn = DriverManager.getConnection(jdbcURL, username, password);
            System.out.println("Connection successful.");
        }
        catch(ClassNotFoundException e)
        {
            //System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
        catch(SQLException e)
        {
            //System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }

        return conn;
    }

    public static Connection getConnection() {
        return conn;
    }

    public static void closeConnection()
    {
        try
        {
            conn.close();
            System.out.println("Connection closed.");
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
        }
    }

}
