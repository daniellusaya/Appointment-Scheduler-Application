package DBAccess;

import Database.DBConnection;
import Model.Divisions;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * This class retrieves data from the first level divisions table in the database.
 */
public class DBDivisions {

    /**
     * This method retrieves all divisions. It runs a SQL statement that gets all the entries from the divisions
     * table, then the retrieved divisions are added to an Observable List.
     */
    public static ObservableList<Divisions> getAllDivisions() {

        ObservableList<Divisions> divisionsList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * from first_level_divisions";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();


            while (rs.next()) {
                int division = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                int countryId = rs.getInt("COUNTRY_ID");

                Divisions divisions = new Divisions(division, divisionName, countryId);
                divisionsList.add(divisions);

            }


        }
        catch(SQLException throwables)
        {
            throwables.printStackTrace();
        }

        return divisionsList;
    }

    /**
     * This method retrieves all divisions by country. It runs a SQL statement that gets all the entries from the divisions
     * table that match the specified country ID, then the retrieved divisions are added to an Observable List.
     */
    public static ObservableList<Divisions> getAllDivisionsByCountry(int countryId) {
        ObservableList<Divisions> divisions = FXCollections.observableArrayList();

        try{
            String sql = "select * from first_level_divisions where Country_ID = ?;";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ps.setInt(1 , countryId);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int divisionId = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                int divisionCountryId = rs.getInt("COUNTRY_ID");

                Divisions newDivision = new Divisions(divisionId, divisionName, divisionCountryId);
                divisions.add(newDivision);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


        return divisions;
    }
}
