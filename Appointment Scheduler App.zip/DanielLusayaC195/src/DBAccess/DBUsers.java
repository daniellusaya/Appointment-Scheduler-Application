package DBAccess;

import Database.DBConnection;
import Model.Users;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * This class retrieves data from the users table in the database.
 */
public class DBUsers {

    /**
     * This method retrieves all users. It runs a SQL statement that gets all the entries from the users table,
     * then the retrieved users are added to an Observable List.
     */
    public static ObservableList<Users> getAllUsers() {

        ObservableList<Users> usersList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * from users";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();


            while (rs.next()) {
                int userID = rs.getInt("User_ID");
                String userName = rs.getString("User_Name");
                String password = rs.getString("Password");

                Users user = new Users(userID, userName, password);
                usersList.add(user);

            }


        }
        catch(SQLException throwables)
        {
            throwables.printStackTrace();
        }

        return usersList;
    }

}
