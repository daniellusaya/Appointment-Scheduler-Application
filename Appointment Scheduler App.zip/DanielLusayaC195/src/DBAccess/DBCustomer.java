package DBAccess;

import Database.DBConnection;
import Model.Customers;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.*;

/**
 * This class retrieves and manipulates data from the customers table in the database.
 */
public class DBCustomer {

    /**
     * This method retrieves all customers. It runs a SQL statement that gets all the entries from the customers
     * table, then the retrieved customers are added to an Observable List which is displayed in Table Views in the
     * application.
     */
    public static ObservableList<Customers> getAllCustomers() {

        ObservableList<Customers> customersList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT Customer_ID, Customer_Name, Address, Phone, Postal_Code, Division," +
                    "customers.Division_ID,Country_ID FROM customers, first_level_divisions " +
                    "WHERE customers.Division_ID = first_level_divisions.Division_ID;";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();


            while (rs.next()) {
                int customerId = rs.getInt("Customer_ID");
                String customerName = rs.getString("Customer_Name");
                String address = rs.getString("Address");
                String postalCode = rs.getString("Postal_Code");
                String phone = rs.getString("Phone");
                int countryId = rs.getInt("Country_ID");
                int divisionId = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");

                Customers customer = new Customers(customerId, customerName, address, postalCode, phone, countryId, divisionId, divisionName);
                customersList.add(customer);

            }


        }
        catch(SQLException throwables)
        {
            throwables.printStackTrace();
        }

        return customersList;
    }

    /**
     * This method adds a customer to the database. It runs a SQL statement that enters values into all the columns
     * in the customers table in the database.
     */
    public static void addCustomerDB(String customerName, String customerAddress, String customerPostalCode, String customerPhone, int divisionId) {

        try {
            String insertStatement = "INSERT INTO customers VALUES(null, ?, ?, ?, ?, null, null, null, null, ?);";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(insertStatement, Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, customerName);
            ps.setString(2, customerAddress);
            ps.setString(3, customerPostalCode);
            ps.setString(4, customerPhone);
            ps.setInt(5, divisionId);

            ps.execute();

            ResultSet rs = ps.getGeneratedKeys();
            rs.next();

            int customerId = rs.getInt(1);
            }
        catch (SQLException e) {

        }
    }

    /**
     * This method modifies an existing customer in the database. It gets the customer that matches the specified
     * customer's ID, then runs a SQL statement that updates all of the existing customer's values except for the
     * customer ID.
     */
    public static void modifyCustomerDB(String customerName, String customerAddress, String customerPostalCode,
                                        String customerPhone, int divisionId, String customerId) {

        try {
            String insertStatement = "UPDATE customers set Customer_Name = ?, Address = ?, Postal_Code = ?, Phone = ?, Division_ID = ?" +
                    " WHERE Customer_ID = ?";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(insertStatement, Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, customerName);
            ps.setString(2, customerAddress);
            ps.setString(3, customerPostalCode);
            ps.setString(4, customerPhone);
            ps.setInt(5, divisionId);
            ps.setString(6, customerId);

            ps.execute();

            ResultSet rs = ps.getGeneratedKeys();
            rs.next();

        }
        catch (SQLException e) {

        }
    }

    /**
     * This method deletes an existing customer in the database. It gets the customer that matches the specified
     * customer's ID, then runs a SQL statement that deletes the customer from the database.
     */
    public static void deleteCustomerDB (int customerID) {
        try {
            String sql = "DELETE from customers where Customer_ID = ?;";
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, customerID);

            ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

