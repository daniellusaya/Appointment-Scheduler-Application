package DBAccess;

import Database.DBConnection;
import Model.Countries;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * This class retrieves data from the countries table in the database.
 */
public class DBCountries {

    /**
     * This method retrieves all countries. It runs a SQL statement that gets all the entries from the countries
     * table, then the retrieved countries are added to an Observable List.
     */
    public static ObservableList<Countries> getAllCountries() {

        ObservableList<Countries> clist = FXCollections.observableArrayList();

        try
        {
            String sql = "SELECT * from countries";
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                int countryId = rs.getInt("Country_ID");
                String countryName = rs.getString("Country");

                Countries C = new Countries(countryId, countryName);
                clist.add(C);
            }
        }

        catch(SQLException throwables)
        {
            throwables.printStackTrace()
            ;
        }

        return clist;
    }

}
