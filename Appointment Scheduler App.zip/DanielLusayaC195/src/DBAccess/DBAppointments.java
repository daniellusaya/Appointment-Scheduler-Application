package DBAccess;

import Database.DBConnection;
import Model.Appointments;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.*;
import java.time.*;
import java.time.temporal.ChronoUnit;

/**
 * This class retrieves and manipulates data from the appointments table in the database.
 */
public class DBAppointments {

    /**
     * This method retrieves all appointments. It runs a SQL statement that gets all the entries from the appointments
     * table, then it converts the appointment table's UTC times to the user's local timezone. The retrieved appointments
     * are then added to an Observable List which is displayed in Table Views in the application.
     */
    public static ObservableList<Appointments> getAllAppointments() {

        ObservableList<Appointments> appointmentsList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT Appointment_ID, Title, Description, Location, Type, Start, End, " +
                    "appointments.Contact_ID, Customer_ID, User_ID, Contact_Name FROM appointments, contacts " +
                    "WHERE contacts.Contact_ID = appointments.Contact_ID;";


            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();


            while (rs.next()) {
                int appointmentId = rs.getInt("Appointment_ID");
                String appointmentTitle = rs.getString("Title");
                String appointmentDescription = rs.getString("Description");
                String appointmentLocation = rs.getString("Location");
                String appointmentType = rs.getString("Type");
                Timestamp appointmentStart = rs.getTimestamp("Start");
                Timestamp appointmentEnd = rs.getTimestamp("End");
                int appointmentContactId = rs.getInt("Contact_ID");
                int appointmentCustomerId = rs.getInt("Customer_ID");
                int appointmentUserId = rs.getInt("User_ID");
                String contactName = rs.getString("Contact_Name");

                ZoneId zoneId = ZoneId.systemDefault();

                LocalDateTime appointmentStartLDT = LocalDateTime.of(appointmentStart.toInstant().atZone(zoneId).toLocalDate(), appointmentStart.toInstant().atZone(zoneId).toLocalTime());
                LocalDateTime appointmentEndLDT = LocalDateTime.of(appointmentEnd.toInstant().atZone(zoneId).toLocalDate(), appointmentEnd.toInstant().atZone(zoneId).toLocalTime());

                Appointments Appointment = new Appointments(appointmentId, appointmentTitle, appointmentDescription, appointmentLocation,
                        appointmentType, appointmentStartLDT, appointmentEndLDT,
                        appointmentCustomerId, appointmentContactId, appointmentUserId, contactName);
                appointmentsList.add(Appointment);

            }


        }
        catch(SQLException throwables)
        {
            throwables.printStackTrace();
        }

        return appointmentsList;
    }

    /**
     * This method retrieves all appointments from the database. It notifies the user if there is an appointment
     * starting within 15 minutes of the user logging in. It converts the appointment's UTC times to the user's local
     * timezone and checks all appointments against the current time.
     */
    public static String getAppointmentAlert() {
        ObservableList<Appointments> appointmentsList = FXCollections.observableArrayList();
        String alert = "You have no appointments within the next 15 minutes.";

        appointmentsList = getAllAppointments();

        for (Appointments appointments : appointmentsList) {
            LocalTime startTime = appointments.getAppointmentStart().toLocalTime();
            LocalDateTime currentLDT = LocalDateTime.now();
            long timeDifference = ChronoUnit.MINUTES.between(startTime, currentLDT);
            long interval = timeDifference * -1;

            if(interval == 0) {
                alert = "You have Appointment #" + appointments.getAppointmentId() + " at " + appointments.getAppointmentStart().toLocalTime()
                        + " - " + appointments.getAppointmentEnd().toLocalTime() + " right now.";
            }
            else if(interval <= 15 && interval > 0) {
                alert = "You have Appointment #" + appointments.getAppointmentId() + " at " + appointments.getAppointmentStart().toLocalTime()
                        + " - " + appointments.getAppointmentEnd().toLocalTime() + " in " + interval + " minute(s).";
            }

        }
        return alert;
    }

    /**
     * This method adds an appointment to the database. It runs a SQL statement that enters values into all the columns
     * in the appointments table in the database.
     */
    public static void addAppointmentDB(String appointmentTitle, String appointmentDescription, String appointmentLocation,
                                        String appointmentType, Timestamp appointmentStart, Timestamp appointmentEnd,
                                        int contact, int customer, int user) {
        try {
            String insertStatement = "INSERT INTO appointments VALUES(null, ?, ?, ?, ?, ?, ?, null, null, null, null, ?, ?, ?);";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(insertStatement, Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, appointmentTitle);
            ps.setString(2, appointmentDescription);
            ps.setString(3, appointmentLocation);
            ps.setString(4, appointmentType);
            ps.setTimestamp(5, appointmentStart);
            ps.setTimestamp(6, appointmentEnd);
            ps.setInt(7, customer);
            ps.setInt(8, user);
            ps.setInt(9, contact);

            ps.execute();

            ResultSet rs = ps.getGeneratedKeys();
            rs.next();

            int appointmentID = rs.getInt(1);
        }
        catch (SQLException e) {

        }
    }

    /**
     * This method modifies an existing appointment in the database. It gets the appointment that matches the specified
     * appointment's ID, then runs a SQL statement that updates all of the existing appointment's values except for the
     * appointment ID.
     */
    public static void modifyAppointmentDB(String appointmentId, String appointmentTitle, String appointmentDescription, String appointmentLocation,
                                           String appointmentType, Timestamp appointmentStart, Timestamp appointmentEnd,
                                           int contactId, int customerId, int userId) {

        try {
            String insertStatement = "UPDATE appointments SET Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, " +
                    "End = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ? WHERE Appointment_ID = ?";

            PreparedStatement ps = DBConnection.getConnection().prepareStatement(insertStatement, Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, appointmentTitle);
            ps.setString(2, appointmentDescription);
            ps.setString(3, appointmentLocation);
            ps.setString(4, appointmentType);
            ps.setTimestamp(5, appointmentStart);
            ps.setTimestamp(6, appointmentEnd);
            ps.setInt(7, customerId);
            ps.setInt(8, userId);
            ps.setInt(9, contactId);
            ps.setString(10, appointmentId);


            ps.execute();

            ResultSet rs = ps.getGeneratedKeys();
            rs.next();

        }
        catch (SQLException e) {

        }
    }

    /**
     * This method deletes an existing appointment in the database. It gets the appointment that matches the specified
     * appointment's ID, then runs a SQL statement that deletes the appointment from the database.
     */
    public static void deleteAppointmentDB (int appointmentId) {
        try {
            String sql = "DELETE from appointments where Appointment_ID = ?;";
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, appointmentId);

            ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method retrieves the contact's name based on the specified contact ID. It runs a SQL statement to get the
     * contact name that matches the specified contact ID.
     */
    public String getContactName(int contactId) throws SQLException {

        String contactName ="";

        try {
            String sqlContacts = "SELECT * FROM contacts WHERE Contact_ID = ?";
            PreparedStatement psContacts = DBConnection.getConnection().prepareStatement(sqlContacts);
            psContacts.setInt(1, contactId);
            ResultSet rsContacts = psContacts.executeQuery();

            while(rsContacts.next()) {
                contactName = rsContacts.getString("Contact_Name");
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return contactName;
    }

    public static void checkDateConversion() {
        System.out.println("CREATE DATE TEST");
        String sql = "select Create_Date from countries";

        try {
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                Timestamp ts = rs.getTimestamp("Create_Date");
                System.out.println("CD: " + ts.toLocalDateTime().toString());
            }
        }

        catch(SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
