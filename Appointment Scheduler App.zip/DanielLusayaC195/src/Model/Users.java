package Model;

/** This class defines users, specifying that each user has an ID, name, and password. */
public class Users {

    private int userId;
    private String userName;
    private String password;

    /** This method creates an Observable List users with parameters ID, name, and password. */
    public Users(int userId, String userName, String password)
    {
        this.userId = userId;
        this.userName = userName;
        this.password = password;

    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() { return (userId + " " + userName); }
}
