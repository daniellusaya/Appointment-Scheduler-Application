package Model;

//public class Error extends Alerts {

    //public Error(int id, String message) {
        //super(id, message);
    //}

//}
