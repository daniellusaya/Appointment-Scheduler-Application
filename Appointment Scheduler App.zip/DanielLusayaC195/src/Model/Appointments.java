package Model;

import DBAccess.DBAppointments;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.time.LocalDateTime;

/** This class defines appointments, specifying that each appointment has an ID, title, description, location, type,
 *  start, end, contact ID, customer ID, user ID, and contact name. */
public class Appointments {

    private int appointmentId;
    private String appointmentTitle;
    private String appointmentDescription;
    private String appointmentLocation;
    private String appointmentType;
    private LocalDateTime appointmentStart;
    private LocalDateTime appointmentEnd;
    private int appointmentContactId;
    private int appointmentCustomerId;
    private int userId;
    private String contactName;

    /** This method creates an Observable List appointments with parameters ID, title, description, location, type,
     *  start, end, contact ID, customer ID, user ID, and contact name. */
    public Appointments(int appointmentId, String appointmentTitle, String appointmentDescription, String appointmentLocation,
                        String appointmentType,
                        LocalDateTime appointmentStart, LocalDateTime appointmentEnd, int appointmentCustomerId,
                        int appointmentContactId, int userId, String contactName)
    {
        this.appointmentId = appointmentId;
        this.appointmentTitle = appointmentTitle;
        this.appointmentDescription = appointmentDescription;
        this.appointmentLocation = appointmentLocation;
        this.appointmentType = appointmentType;
        this.appointmentStart = appointmentStart;
        this.appointmentEnd = appointmentEnd;
        this.appointmentCustomerId = appointmentCustomerId;
        this.appointmentContactId = appointmentContactId;
        this.userId = userId;
        this.contactName = contactName;

    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public static void setAllAppointments(ObservableList<Appointments> allAppointments) {
        Appointments.allAppointments = allAppointments;
    }

    public int getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }

    public String getAppointmentTitle() {
        return appointmentTitle;
    }

    public void setAppointmentTitle(String appointmentTitle) {
        this.appointmentTitle = appointmentTitle;
    }

    public String getAppointmentDescription() {
        return appointmentDescription;
    }

    public void setAppointmentDescription(String appointmentDescription) {
        this.appointmentDescription = appointmentDescription;
    }

    public String getAppointmentLocation() {
        return appointmentLocation;
    }

    public void setAppointmentLocation(String appointmentLocation) {
        this.appointmentLocation = appointmentLocation;
    }

    public String getAppointmentType() {
        return appointmentType;
    }

    public void setAppointmentType(String appointmentType) {
        this.appointmentType = appointmentType;
    }

    public LocalDateTime getAppointmentStart() { return appointmentStart; }

    public void setAppointmentStart(LocalDateTime appointmentStart) {this.appointmentStart = appointmentStart;}

    public LocalDateTime getAppointmentEnd() {
        return appointmentEnd;
    }

    public void setAppointmentEnd(LocalDateTime appointmentEnd) {
        this.appointmentEnd = appointmentEnd;
    }


    public int getAppointmentCustomerId() {
        return appointmentCustomerId;
    }

    public void setAppointmentCustomerId(int appointmentCustomerId) {
        this.appointmentCustomerId = appointmentCustomerId;
    }

    public int getAppointmentContactId() {
        return appointmentContactId;
    }

    public void setAppointmentContactId(int appointmentContact) {
        this.appointmentContactId = appointmentContact;
    }

    public static void addAppointment(Appointments newAppointment) {
        allAppointments.add(newAppointment);
    }

    private static ObservableList<Appointments> allAppointments = FXCollections.observableArrayList();

    public static ObservableList<Appointments> getAllAppointments() {return allAppointments;}

    @Override
    public String toString() { return (appointmentStart + "-" + appointmentEnd + "-00"); }

    public static Appointments lookupAppointmentId(int appointmentId)
    {
        ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();

        for(Appointments appointments : allAppointments) {
            if(appointments.getAppointmentId() == appointmentId) {
                return appointments;
            }
        }
        return null;
    }

    public static ObservableList<Appointments> lookupAppointmentStr(String appointmentTitle)
    {
        ObservableList<Appointments> namedAppointments = FXCollections.observableArrayList();
        ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();

        for(Appointments appointments : allAppointments) {
            if(appointments.getAppointmentTitle().contains(appointmentTitle)) {
                namedAppointments.add(appointments);
            }
        }
        return namedAppointments;
    }

}