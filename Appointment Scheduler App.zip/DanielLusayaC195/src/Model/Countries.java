package Model;

/** This class defines countries, specifying that each country has an ID and name. */
public class Countries {
    private int countryId;
    private String countryName;

    /** This method creates an Observable List countries with parameters ID and name. */
    public Countries(int countryId, String countryName) {
        this.countryId = countryId;
        this.countryName = countryName;

    }
    public int getCountryId() {
        return countryId;
    }

    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    @Override
    public String toString() { return (countryName); }
}