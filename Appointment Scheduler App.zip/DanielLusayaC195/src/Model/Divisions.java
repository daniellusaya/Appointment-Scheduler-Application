package Model;

/** This class defines divisions, specifying that each division has an ID, name, and country. */
public class Divisions {

    private int divisionId;
    private String divisionName;
    private int countryId;

    /** This method creates an Observable List divisions with parameters ID, name, and country ID. */
    public Divisions(int divisionId, String divisionName, int countryId) {
        this.divisionId = divisionId;
        this.divisionName = divisionName;
        this.countryId = countryId;
    }

    public int getDivisionId() {
        return divisionId;
    }

    public void setDivisionId(int divisionId) {
        this.divisionId = divisionId;
    }

    public String getDivisionName() {
        return divisionName;
    }

    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

    public int getCountryId() {
        return countryId;
    }

    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    @Override
    public String toString() { return (divisionName); }
}
