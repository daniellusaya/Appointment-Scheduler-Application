package Model;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.util.Optional;

public class Confirmation extends Alerts {

    public Confirmation(String message, String title) {
        super(message, Alert.AlertType.CONFIRMATION, title);


    }

    @Override
    public boolean generateAlert() {
        Optional<ButtonType> result = alert.showAndWait();
        return (result.isPresent() && result.get() == ButtonType.OK);
    }
}
