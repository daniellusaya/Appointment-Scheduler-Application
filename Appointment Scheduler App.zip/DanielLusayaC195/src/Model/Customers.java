package Model;

import DBAccess.DBAppointments;
import DBAccess.DBCustomer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/** This class defines customers, specifying that each customer has an ID, name, address, postal code, phone number,
 *  country, and division. */
public class Customers {

    private int customerId;
    private String customerName;
    private String address;
    private String postalCode;
    private String phone;
    private int countryId;
    private int divisionId;
    private String divisionName;

    /** This method creates an Observable List customers with parameters ID, name, address, postal code, phone number,
     *  country ID, division ID and division name. */
    public Customers(int customerId, String customerName, String address, String postalCode, String phone, int countryId, int division, String divisionName)
    {
        this.customerId = customerId;
        this.customerName = customerName;
        this.address = address;
        this.postalCode = postalCode;
        this.phone = phone;
        this.divisionId = division;
        this.countryId = countryId;
        this.divisionName = divisionName;

    }

    public int getDivisionId() {
        return divisionId;
    }

    public String getDivisionName() {
        return divisionName;
    }

    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

    public int getCountryId() {
        return countryId;
    }

    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    public void setDivision(int divisionId) {
        this.divisionId = divisionId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getDivision() {
        return divisionId;
    }

    public void setDivisionId(int division) {
        this.divisionId = division;
    }

    @Override
    public String toString() { return (customerId + " " + customerName); }
    //public int toInt() {}

    public static Customers lookupCustomerId(int customerId)
    {
        ObservableList<Customers> allCustomers = DBCustomer.getAllCustomers();

        for(Customers customers : allCustomers) {
            if(customers.getCustomerId() == customerId) {
                return customers;
            }
        }
        return null;
    }

    public static ObservableList<Customers> lookupCustomerStr(String customerName)
    {
        ObservableList<Customers> namedCustomers = FXCollections.observableArrayList();
        ObservableList<Customers> allCustomers = DBCustomer.getAllCustomers();

        for(Customers customers : allCustomers) {
            if(customers.getCustomerName().contains(customerName)) {
                namedCustomers.add(customers);
            }
        }
        return namedCustomers;
    }
}
