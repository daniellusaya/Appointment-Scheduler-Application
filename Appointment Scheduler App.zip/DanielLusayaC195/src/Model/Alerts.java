package Model;

import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;

import java.util.Optional;

public abstract class Alerts {

    protected Alert alert;

    protected Alerts(String message, Alert.AlertType alertType, String title) {
        this.alert = new Alert(alertType);

        alert.setTitle(title);
        alert.setContentText(message);
    }

    public abstract boolean generateAlert();

}
