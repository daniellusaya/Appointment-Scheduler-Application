package Model;

/** This class defines contacts, specifying that each contact has an ID, name, and email. */
public class Contacts {

    private int contactId;
    private String contactName;
    private String email;

    /** This method creates an Observable List contacts with parameters ID, name, and email. */
    public Contacts(int contactId, String contactName, String email)
    {
        this.contactId = contactId;
        this.contactName = contactName;
        this.email = email;

    }

    public int getContactId() {
        return contactId;
    }

    public void setContactId(int contactId) {
        this.contactId = contactId;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() { return (contactId + " " + contactName); }
}
