package Model;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.util.Optional;

public class Warning extends Alerts {

    public Warning(String message, String title) {

        super(message, Alert.AlertType.WARNING, title);
    }

    @Override
    public boolean generateAlert() {
        alert.showAndWait();
        return false;
    }
}
